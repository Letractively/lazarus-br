/*
	BASSMIDI test player
	Copyright (c) 2006-2009 Un4seen Developments Ltd.
*/

#include <gtk/gtk.h>
#include <glade/glade.h>
#include <glib/gthread.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <regex.h>
#include <glob.h>
#include "bass.h"
#include "bassmidi.h"

// path to glade file
#ifndef GLADE_PATH
#define GLADE_PATH ""
#endif

GladeXML *glade;
GtkWidget *win=0;
GtkWidget *filesel,*fontfilesel;

HSTREAM chan;		// channel handle
HSOUNDFONT font;	// soundfont

char lyrics[1000]; // lyrics buffer

// display error messages
void Error(const char *es)
{
	GtkWidget *dialog=gtk_message_dialog_new(GTK_WINDOW(win),GTK_DIALOG_DESTROY_WITH_PARENT,
		GTK_MESSAGE_ERROR,GTK_BUTTONS_OK,"%s\n(error code: %d)",es,BASS_ErrorGetCode());
	gtk_dialog_run(GTK_DIALOG(dialog));
	gtk_widget_destroy(dialog);
}

#define GetWidget(id) glade_xml_get_widget(glade,id)

void WindowDestroy(GtkObject *obj, gpointer data)
{
	gtk_main_quit();
}

void CALLBACK LyricSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	BASS_MIDI_MARK mark;
	const char *text;
	int lines;
	BASS_MIDI_StreamGetMark(channel,(DWORD)user,data,&mark); // get the lyric/text
	text=mark.text;
	if (text[0]=='@') return; // skip info
	if (text[0]=='\\') // clear display
		strcpy(lyrics,text+1);
	else {
		if (text[0]=='/') { // new line
			strcat(lyrics,"\n");
			text++;
		}
		strcat(lyrics,text);
	}
	for (lines=1,text=lyrics;text=strchr(text,'\n');lines++,text++) ; // count lines
	if (lines>3) { // remove old lines so that new lines fit in display...
		int a;
		for (a=0,text=lyrics;a<lines-3;a++) text=strchr(text,'\n')+1;
		strcpy(lyrics,text);
	}
	// update the lyrics display
	gdk_threads_enter();
	gtk_label_set_text(GTK_LABEL(GetWidget("lyrics")),lyrics);
	gdk_threads_leave();
}

void CALLBACK EndSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	lyrics[0]=0; // clear lyrics
	gdk_threads_enter();
	gtk_label_set_text(GTK_LABEL(GetWidget("lyrics")),lyrics);
	gdk_threads_leave();
}

// look for a marker (eg. loop points)
BOOL FindMarker(HSTREAM handle, const char *text, BASS_MIDI_MARK *mark)
{
	int a;
	for (a=0;BASS_MIDI_StreamGetMark(handle,BASS_MIDI_MARK_MARKER,a,mark);a++) {
		if (!strcasecmp(mark->text,text)) return TRUE; // found it
	}
	return FALSE;
}

void CALLBACK LoopSync(HSYNC handle, DWORD channel, DWORD data, void *user)
{
	BASS_MIDI_MARK mark;
	if (FindMarker(channel,"loopstart",&mark)) // found a loop start point
		BASS_ChannelSetPosition(channel,mark.pos,BASS_POS_BYTE|BASS_MIDI_DECAYSEEK); // rewind to it (and let old notes decay)
	else
		BASS_ChannelSetPosition(channel,0,BASS_POS_BYTE|BASS_MIDI_DECAYSEEK); // else rewind to the beginning instead
}

gboolean FileExtensionFilter(const GtkFileFilterInfo *info, gpointer data)
{
	return !regexec((regex_t*)data,info->filename,0,NULL,0);
}

void OpenClicked(GtkButton *obj, gpointer data)
{
	int resp=gtk_dialog_run(GTK_DIALOG(filesel));
	gtk_widget_hide(filesel);
	if (resp==GTK_RESPONSE_ACCEPT) {
		char *file=gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(filesel));
		BASS_StreamFree(chan); // free old stream before opening new
		gtk_label_set_text(GTK_LABEL(GetWidget("lyrics")),""); // clear lyrics display
		if (!(chan=BASS_MIDI_StreamCreateFile(FALSE,file,0,0,
				BASS_SAMPLE_FLOAT|BASS_SAMPLE_LOOP|BASS_MIDI_DECAYSEEK|(gtk_toggle_button_get_active(GTK_TOGGLE_BUTTON(GetWidget("fx")))?0:BASS_MIDI_NOFX),0))) {
			// it ain't a MIDI
			gtk_button_set_label(obj,"click here to open a file...");
			gtk_label_set_text(GTK_LABEL(GetWidget("info")),"");
			gtk_range_set_range(GTK_RANGE(GetWidget("position")),0,0);
			Error("Can't play the file");
		} else {
			gtk_button_set_label(obj,file);
			// set the title (first text in first track)
			gtk_label_set_text(GTK_LABEL(GetWidget("info")),BASS_ChannelGetTags(chan,BASS_TAG_MIDI_TRACK));
			{ // update pos scroller range
				QWORD bytes=BASS_ChannelGetLength(chan,BASS_POS_BYTE);
				DWORD time=BASS_ChannelBytes2Seconds(chan,bytes);
				gtk_range_set_range(GTK_RANGE(GetWidget("position")),0,time); // update scroller range
			}
			{ // set looping syncs
				BASS_MIDI_MARK mark;
				if (FindMarker(chan,"loopend",&mark)) // found a loop end point
					BASS_ChannelSetSync(chan,BASS_SYNC_POS|BASS_SYNC_MIXTIME,mark.pos,LoopSync,0); // set a sync there
				BASS_ChannelSetSync(chan,BASS_SYNC_END|BASS_SYNC_MIXTIME,0,LoopSync,0); // set one at the end too (eg. in case of seeking past the loop point)
			}
			{ // clear lyrics buffer and set lyrics syncs
				BASS_MIDI_MARK mark;
				lyrics[0]=0;
				if (BASS_MIDI_StreamGetMark(chan,BASS_MIDI_MARK_LYRIC,0,&mark)) // got lyrics
					BASS_ChannelSetSync(chan,BASS_SYNC_MIDI_LYRIC,0,LyricSync,(void*)BASS_MIDI_MARK_LYRIC);
				else if (BASS_MIDI_StreamGetMark(chan,BASS_MIDI_MARK_TEXT,20,&mark)) // got text instead (over 20 of them)
					BASS_ChannelSetSync(chan,BASS_SYNC_MIDI_TEXT,0,LyricSync,(void*)BASS_MIDI_MARK_TEXT);
				BASS_ChannelSetSync(chan,BASS_SYNC_END,0,EndSync,0);
			}
			{ // get default soundfont in case of matching soundfont being used
				BASS_MIDI_FONT sf;
				BASS_MIDI_StreamGetFonts(chan,&sf,1);
				font=sf.font;
			}
			BASS_ChannelPlay(chan,FALSE);
		}
		g_free(file);
	}
}

void OpenFontClicked(GtkButton *obj, gpointer data)
{
	int resp=gtk_dialog_run(GTK_DIALOG(fontfilesel));
	gtk_widget_hide(fontfilesel);
	if (resp==GTK_RESPONSE_ACCEPT) {
		char *file=gtk_file_chooser_get_filename(GTK_FILE_CHOOSER(fontfilesel));
		HSOUNDFONT newfont;
		if ((newfont=BASS_MIDI_FontInit(file,0)) && newfont!=font) {
			BASS_MIDI_FONT sf;
			sf.font=newfont;
			sf.preset=-1; // use all presets
			sf.bank=0; // use default bank(s)
			BASS_MIDI_StreamSetFonts(0,&sf,1); // set default soundfont
			BASS_MIDI_StreamSetFonts(chan,&sf,1); // set for current stream too
			BASS_MIDI_FontFree(font); // free old soundfont
			font=newfont;
		}
		g_free(file);
	}
}

void FXToggled(GtkToggleButton *obj, gpointer data)
{ // toggle FX processing
	if (obj->active)
		BASS_ChannelFlags(chan,0,BASS_MIDI_NOFX); // enable FX
	else
		BASS_ChannelFlags(chan,BASS_MIDI_NOFX,BASS_MIDI_NOFX); // disable FX
}

gboolean PositionChange(GtkRange *range, GtkScrollType scroll, gdouble value, gpointer data)
{
	BASS_ChannelSetPosition(chan,BASS_ChannelSeconds2Bytes(chan,value),BASS_POS_BYTE);
	lyrics[0]=0; // clear lyrics
	gtk_label_set_text(GTK_LABEL(GetWidget("lyrics")),lyrics);
	return FALSE;
}

gboolean TimerProc(gpointer data)
{
	gtk_range_set_value(GTK_RANGE(GetWidget("position")),BASS_ChannelBytes2Seconds(chan,BASS_ChannelGetPosition(chan,BASS_POS_BYTE))); // update position
	{
		static int updatefont=0;
		if (++updatefont&1) { // only updating font info once a second
			char text[40]="no soundfont";
			BASS_MIDI_FONTINFO i;
			if (BASS_MIDI_FontGetInfo(font,&i))
				sprintf(text,"name: %s\nloaded: %d / %d",i.name,i.samload,i.samsize);
			gtk_label_set_text(GTK_LABEL(GetWidget("fontinfo")),text); // clear lyrics display
		}
	}
	return TRUE;
}

int main(int argc, char* argv[])
{
	g_thread_init(NULL);
	gdk_threads_init();
	gtk_init(&argc,&argv);

	// check the correct BASS was loaded
	if (HIWORD(BASS_GetVersion())!=BASSVERSION) {
		Error("An incorrect version of BASS was loaded");
		return 0;
	}

	// initialize default output device
	if (!BASS_Init(-1,44100,0,NULL,NULL)) {
		Error("Can't initialize device");
		return 0;
	}

	// initialize GUI
	glade=glade_xml_new(GLADE_PATH"miditest.glade",NULL,NULL);
	if (!glade) return 0;
	win=GetWidget("window1");
	if (!win) return 0;
	glade_xml_signal_autoconnect(glade);

	{ // setup file selectors
		GtkFileFilter *filter;
		regex_t *fregex;
		filesel=gtk_file_chooser_dialog_new("Open File",GTK_WINDOW(win),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL,GTK_RESPONSE_CANCEL,GTK_STOCK_OPEN,GTK_RESPONSE_ACCEPT,NULL);
		filter=gtk_file_filter_new();
		gtk_file_filter_set_name(filter,"MIDI files (mid/midi/rmi/kar)");
		fregex=malloc(sizeof(*fregex));
		regcomp(fregex,"\\.(mid|midi|rmi|kar)$",REG_ICASE|REG_NOSUB|REG_EXTENDED);
		gtk_file_filter_add_custom(filter,GTK_FILE_FILTER_FILENAME,FileExtensionFilter,fregex,NULL);
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(filesel),filter);
		filter=gtk_file_filter_new();
		gtk_file_filter_set_name(filter,"All files");
		gtk_file_filter_add_pattern(filter,"*");
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(filesel),filter);

		fontfilesel=gtk_file_chooser_dialog_new("Open Soundfont",GTK_WINDOW(win),GTK_FILE_CHOOSER_ACTION_OPEN,
			GTK_STOCK_CANCEL,GTK_RESPONSE_CANCEL,GTK_STOCK_OPEN,GTK_RESPONSE_ACCEPT,NULL);
		filter=gtk_file_filter_new();
		gtk_file_filter_set_name(filter,"Soundfonts (sf2/sf2pack)");
		fregex=malloc(sizeof(*fregex));
		regcomp(fregex,"\\.(sf2|sf2pack)$",REG_ICASE|REG_NOSUB|REG_EXTENDED);
		gtk_file_filter_add_custom(filter,GTK_FILE_FILTER_FILENAME,FileExtensionFilter,fregex,NULL);
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(fontfilesel),filter);
		filter=gtk_file_filter_new();
		gtk_file_filter_set_name(filter,"All files");
		gtk_file_filter_add_pattern(filter,"*");
		gtk_file_chooser_add_filter(GTK_FILE_CHOOSER(fontfilesel),filter);
	}

	// load optional plugins for packed soundfonts (others may be used too)
	BASS_PluginLoad("libbassflac.so",0);
	BASS_PluginLoad("libbasswv.so",0);

	g_timeout_add(500,TimerProc,NULL);

	gdk_threads_enter();
	gtk_main();
	gdk_threads_leave();

	gtk_widget_destroy(filesel);

	// free the output device and all plugins
	BASS_Free();
	BASS_PluginFree(0);

    return 0;
}
