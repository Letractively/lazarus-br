
# hash value = 106627412
ajedit.rsebasetoobig='Base > 36 not supported'


# hash value = 638641
ajedit.rsebasetoosmall='Base must be greater than 1'

