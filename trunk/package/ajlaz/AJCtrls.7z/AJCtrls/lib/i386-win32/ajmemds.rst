
# hash value = 108774580
ajmemds.smemnorecords='No data found'


# hash value = 88827668
ajmemds.sinvalidfields='No fields defined'

