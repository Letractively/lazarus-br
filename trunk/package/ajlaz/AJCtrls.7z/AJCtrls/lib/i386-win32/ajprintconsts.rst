
# hash value = 3544080
ajprintconsts.sajprintversion='3.1.0'


# hash value = 14262607
ajprintconsts.sconfirm='Confirma'#231#227'o'


# hash value = 175699249
ajprintconsts.swarning='Advert'#234'ncia'


# hash value = 313743
ajprintconsts.serror='Erro'


# hash value = 163939841
ajprintconsts.sinvalidprinter='A impressora selecionada ( %s ) n'#227'o '#233+
' v'#225'lida'


# hash value = 123245617
ajprintconsts.snoinstalledprinter='Nenhuma impressora est'#225' instalada'+


# hash value = 83793473
ajprintconsts.snodefaultprinter='Nenhuma impressora padr'#227'o seleciona'+
'da'


# hash value = 164197599
ajprintconsts.snotprinting='A impressora %s n'#227'o est'#225' imprimindo'+


# hash value = 259666163
ajprintconsts.sprinting='Impress'#227'o em andamento na impressora %s'


# hash value = 1390771
ajprintconsts.sopenprintererror='N'#227'o foi poss'#237'vel abrir a impre'+
'ssora %s'


# hash value = 189085059
ajprintconsts.scloseprintererror='N'#227'o foi poss'#237'vel fechar a imp'+
'ressora %s'


# hash value = 148819955
ajprintconsts.sabortprintererror='N'#227'o foi poss'#237'vel abortar o tr'+
'abalho na impressora %s'


# hash value = 181361811
ajprintconsts.sstartdocerror='N'#227'o foi poss'#237'vel iniciar o docume'+
'nto %s na impressora %s'


# hash value = 88621091
ajprintconsts.senddocerror='N'#227'o foi poss'#237'vel finalizar o docume'+
'nto %s na impressora %s'


# hash value = 264628979
ajprintconsts.sstartpageerror='N'#227'o foi poss'#237'vel iniciar a p'#225+
'gina na impressora %s'


# hash value = 10015203
ajprintconsts.sendpageerror='N'#227'o foi poss'#237'vel finalizar a p'#225+
'gina na impressora %s'


# hash value = 148645539
ajprintconsts.swriteerror='N'#227'o foi poss'#237'vel enviar dados para a'+
' impressora %s'


# hash value = 33143377
ajprintconsts.sprinterselection='Sele'#231#227'o de impressora'


# hash value = 74267376
ajprintconsts.sprintertypeselect=' Selecione o tipo de impressora: '


# hash value = 143115186
ajprintconsts.sprintercanvas='Jato de tinta ou Laser'


# hash value = 193973500
ajprintconsts.sprinterdotmatrix='Matricial'


# hash value = 1339
ajprintconsts.sprinterselectionok='OK'


# hash value = 110146494
ajprintconsts.sprintprogress='Imprimindo. Por favor, aguarde...'


# hash value = 128145727
ajprintconsts.spreviewtitle='Visualizar impress'#227'o'


# hash value = 93863042
ajprintconsts.spreviewsavetitle='Salvar'


# hash value = 126514511
ajprintconsts.spreviewsavefilter='Documento de texto'


# hash value = 254880304
ajprintconsts.spreviewprinthint='Imprimir'#13'Alt + P'


# hash value = 183649347
ajprintconsts.spreviewsavehint='Salvar para arquivo texto'#13'Alt + S'


# hash value = 143990453
ajprintconsts.spreviewpdfhint='Exportar para Adobe PDF'#13'Alt + E'


# hash value = 150592029
ajprintconsts.spreviewmailhint='Enviar e-mail'#13'Alt + M'


# hash value = 235513333
ajprintconsts.spreviewfirsthint='Ir para a primeira p'#225'gina'#13'Ctrl '+
'+ Home'


# hash value = 57651776
ajprintconsts.spreviewpriorhint='Ir para a p'#225'gina anterior'#13'Ctrl '+
'+ PageUp'


# hash value = 4203038
ajprintconsts.spreviewnexthint='Ir para a pr'#243'xima p'#225'gina'#13'Ct'+
'rl + PageDown'


# hash value = 2884692
ajprintconsts.spreviewlasthint='Ir para a '#250'ltima p'#225'gina'#13'Ctr'+
'l + End'


# hash value = 249575342
ajprintconsts.spreviewgotohint='Ir para a p'#225'gina...'


# hash value = 267402200
ajprintconsts.spreviewclosehint='Fechar visualiza'#231#227'o'#13'Alt + X'


# hash value = 161243791
ajprintconsts.spreviewclose='Fechar visualiza'#231#227'o?'


# hash value = 141434484
ajprintconsts.spreviewpages='P'#225'gina %d de %d'


# hash value = 21098694
ajprintconsts.spdfsave='Salvar arquivo PDF'


# hash value = 208379702
ajprintconsts.spdfsavefilter='Arquivos Adobe PDF'


# hash value = 235483022
ajprintconsts.spdfnofilename='Sem nome de arquivo para salvar o PDF.'

