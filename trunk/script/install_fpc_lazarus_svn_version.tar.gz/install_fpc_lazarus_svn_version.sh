#!/bin/sh
# Script by silvioprog - http://silvioprog.com.br

set -e

echo "********************************************************"
echo "*                                                      *"
echo "*              Automated installation v1.0             *"
echo "*         for install Lazarus/FPC (SVN version)        *"
echo "*                                                      *"
echo "*         Script by silvioprog and Lazarus team        *"
echo "*                                                      *"
echo "*   This script is designed for Ubuntu x86 (32 Bit)    *"
echo "*                                                      *"
echo "********************************************************"
echo ""
echo "WARNING: The installation will take a while, please wait!"

echo ""
echo "Step 1: Installing dependencies..."
echo ""
sudo apt-get update
sudo apt-get upgrade -y
sudo apt-get install --force-yes -y subversion fpc fp-utils fpc-source fp-units-misc

echo ""
echo "Step 2: Downloading files..."
echo ""
cd ~
svn co http://svn.freepascal.org/svn/fpc/trunk fpc
svn co http://svn.freepascal.org/svn/lazarus/trunk lazarus
wget -c ftp://ftp.freepascal.org/fpc/snapshot/v25/i386-linux/fpc-2.5.1.i386-linux.tar.gz

echo ""
echo "Step 3: Unzipping FPC..."
echo ""
mv fpc-2.5.1.i386-linux.tar.gz fpc/
cd fpc/
tar -vzxf fpc-2.5.1.i386-linux.tar.gz
rm -f fpc-2.5.1.i386-linux.tar.gz

echo ""
echo "Step 4: Updatting FPC SVN..."
echo ""
svn update

echo ""
echo "Step 5: Compiling new FPC..."
echo ""
make clean all

echo ""
echo "Step 6: Removing old FPC..."
echo ""
sudo apt-get remove -y fpc fp-utils fpc-source fp-units-misc fp-*
sudo rm -f /etc/fpc.cfg

echo ""
echo "Step 7: Installing new FPC..."
echo ""
sudo rm -Rf /usr/share/doc/fpc-2.5.1
sudo ln -sf /home/$USER/fpc/share/doc/fpc-2.5.1 /usr/share/doc
sudo rm -Rf /usr/share/fpcsrc
sudo ln -sf /home/$USER/fpc /usr/share/fpcsrc
sudo rm -Rf /usr/lib/fpc
sudo ln -sf /home/$USER/fpc/lib/fpc /usr/lib
sudo ln -sf /usr/lib/fpc/2.5.1/ppc386 /usr/bin/ppc386
sudo ln -sf /home/$USER/fpc/bin/bin2obj /home/$USER/fpc/bin/chmcmd /home/$USER/fpc/bin/chmls /home/$USER/fpc/bin/data2inc /home/$USER/fpc/bin/delp /home/$USER/fpc/bin/fd2pascal /home/$USER/fpc/bin/fp /home/$USER/fpc/bin/fpc /home/$USER/fpc/bin/fpclasschart /home/$USER/fpc/bin/fpcmake /home/$USER/fpc/bin/fpcmkcfg /home/$USER/fpc/bin/fpcres /home/$USER/fpc/bin/fpcsubst /home/$USER/fpc/bin/fpdoc /home/$USER/fpc/bin/fppkg /home/$USER/fpc/bin/fprcp /home/$USER/fpc/bin/grab_vcsa /home/$USER/fpc/bin/h2pas /home/$USER/fpc/bin/h2paspp /home/$USER/fpc/bin/instantfpc /home/$USER/fpc/bin/makeskel /home/$USER/fpc/bin/mkarmins /home/$USER/fpc/bin/mkx86ins /home/$USER/fpc/bin/plex /home/$USER/fpc/bin/postw32 /home/$USER/fpc/bin/ppdep /home/$USER/fpc/bin/ppudump /home/$USER/fpc/bin/ppufiles /home/$USER/fpc/bin/ppumove /home/$USER/fpc/bin/ptop /home/$USER/fpc/bin/pyacc /home/$USER/fpc/bin/rmcvsdir /home/$USER/fpc/bin/rstconv /home/$USER/fpc/bin/unitdiff /bin
sudo /usr/lib/fpc/2.5.1/samplecfg /usr/lib/fpc/2.5.1/ /etc

echo ""
echo "Step 8: Updatting Lazarus SVN..."
echo ""
cd ../lazarus
svn update

echo ""
echo "Step 9: Compiling Lazarus..."
echo ""
make clean all
make bigideclean bigide

echo ""
echo "Step 10: Creating links and menu item of Lazarus..."
echo ""
sudo ln -sf /home/$USER/lazarus/startlazarus /bin
sudo ln -sf /home/$USER/lazarus/lazarus /bin
echo "[Desktop Entry]
Encoding=UTF-8
Categories=Application;IDE;Development;GTK;GUIDesigner;
Type=Application
Terminal=false
Icon[pt_BR]=/home/silvioprog/lazarus/images/ide_icon48x48.png
Name[pt_BR]=Lazarus
Exec=startlazarus %f
Name=Lazarus
Comment=Lazarus IDE
StartupWMClass=Lazarus
MimeType=text/x-pascal;text/lazarus-project-source;text/lazarus-project-information;text/lazarus-form;text/lazarus-resource;text/lazarus-package;text/lazarus-package-link;text/lazarus-code-inlay;
Patterns=*.pas;*.pp;*.p;*.inc;*.lpi;*.lpk;*.lpr;*.lfm;*.lrs;*.lpl;*.dci
Icon=/home/silvioprog/lazarus/images/mimetypes/text-lazarus-project-information.png" > /tmp/lazarus.desktop
sudo mv /tmp/lazarus.desktop /usr/share/applications/

echo "***********************************************"
echo "*         The automated installation          *"
echo "*                     is                      *"
echo "*                 finished! :)                *"
echo "*                                             *"
echo "*     Open Lazarus in menu of your system.    *"
echo "*                                             *"
echo "*     Please, now follow see this thread:     *"
echo "***********************************************"
echo "http://lists.lazarus.freepascal.org/pipermail/lazarus/2011-May/063321.html"
echo ""
echo "Enjoy!"
